'use client';

import React, { useState, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogTrigger, DialogFooter, DialogClose } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { Separator } from '@/components/ui/separator';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Skeleton } from '@/components/ui/skeleton';
import {
  Film, Users, Camera, Clapperboard, PenTool, Wrench, Search, Star,
  Plus, Upload, Play, DollarSign, Mail, Phone, MapPin, Award,
  ChevronRight, Menu, X, User, Settings, LogOut, Eye, Calendar,
  Briefcase, Heart, Sparkles, Crown, Shield, CheckCircle2, ArrowLeft,
  Video, FileText, UserPlus, TrendingUp, Clock, Globe, LayoutGrid, List
} from 'lucide-react';

// ============================================================
// TYPES
// ============================================================
interface User {
  id: string;
  email: string;
  name: string;
  role: string;
  phone?: string;
  bio?: string;
  avatar?: string;
  reelUrl?: string;
  chargingPrice?: string;
  location?: string;
  skills?: string;
  isPremium: boolean;
  works?: Work[];
  monologues?: Monologue[];
  auditions?: Audition[];
  scripts?: Script[];
}

interface Work {
  id: string;
  title: string;
  type: string;
  role?: string;
  year?: string;
  description?: string;
  imageUrl?: string;
  videoUrl?: string;
}

interface Monologue {
  id: string;
  title: string;
  genre?: string;
  description?: string;
  videoUrl?: string;
}

interface Audition {
  id: string;
  title: string;
  description?: string;
  roles?: string;
  location?: string;
  deadline?: string;
  requirements?: string;
  postedBy: string;
  user?: { name: string; role: string; };
}

interface Script {
  id: string;
  title: string;
  genre?: string;
  synopsis?: string;
  pages?: number;
  status: string;
  contactEmail?: string;
  writerId: string;
  writer?: { name: string; };
}

type View = 'home' | 'browse' | 'profile' | 'dashboard' | 'auditions' | 'scripts' | 'login' | 'register' | 'recommendations';

// ============================================================
// API HELPER
// ============================================================
const api = async (url: string, options?: RequestInit) => {
  const res = await fetch(url, { ...options, headers: { 'Content-Type': 'application/json', ...options?.headers } });
  return res.json();
};

// ============================================================
// MAIN APP COMPONENT
// ============================================================
export default function FilmCastHub() {
  const [view, setView] = useState<View>('home');
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedRole, setSelectedRole] = useState<string>('all');

  // Check if user is logged in on mount
  useEffect(() => {
    const stored = localStorage.getItem('filmcast_user');
    if (stored) {
      try {
        setCurrentUser(JSON.parse(stored));
      } catch { localStorage.removeItem('filmcast_user'); }
    }
  }, []);

  const logout = () => {
    setCurrentUser(null);
    localStorage.removeItem('filmcast_user');
    setView('home');
  };

  // ============================================================
  // ANIMATION VARIANTS
  // ============================================================
  const fadeUp = {
    initial: { opacity: 0, y: 30 },
    animate: { opacity: 1, y: 0 },
    exit: { opacity: 0, y: -20 },
    transition: { duration: 0.5 }
  };

  const stagger = {
    animate: { transition: { staggerChildren: 0.1 } }
  };

  // ============================================================
  // NAVIGATION BAR
  // ============================================================
  const Navbar = () => (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-black/90 backdrop-blur-xl border-b border-amber-500/20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <button onClick={() => setView('home')} className="flex items-center gap-2 group">
            <div className="w-10 h-10 bg-gradient-to-br from-amber-400 to-amber-600 rounded-xl flex items-center justify-center shadow-lg shadow-amber-500/30 group-hover:shadow-amber-500/50 transition-shadow">
              <Film className="w-6 h-6 text-black" />
            </div>
            <span className="text-xl font-bold bg-gradient-to-r from-amber-300 to-amber-500 bg-clip-text text-transparent">
              FilmCast Hub
            </span>
          </button>

          {/* Desktop Nav */}
          <div className="hidden md:flex items-center gap-1">
            <NavButton icon={<LayoutGrid className="w-4 h-4" />} label="Browse" onClick={() => setView('browse')} />
            <NavButton icon={<Clapperboard className="w-4 h-4" />} label="Auditions" onClick={() => setView('auditions')} />
            <NavButton icon={<FileText className="w-4 h-4" />} label="Scripts" onClick={() => setView('scripts')} />
            {currentUser && (
              <>
                <NavButton icon={<Sparkles className="w-4 h-4" />} label="For You" onClick={() => setView('recommendations')} />
                <NavButton icon={<User className="w-4 h-4" />} label="Dashboard" onClick={() => setView('dashboard')} />
              </>
            )}
          </div>

          {/* Right Side */}
          <div className="hidden md:flex items-center gap-3">
            {currentUser ? (
              <div className="flex items-center gap-3">
                <Badge variant="outline" className="border-amber-500 text-amber-400 flex items-center gap-1">
                  {currentUser.isPremium ? <Crown className="w-3 h-3" /> : <Shield className="w-3 h-3" />}
                  {currentUser.isPremium ? 'PRO' : 'Free'}
                </Badge>
                <Button variant="ghost" size="sm" className="text-zinc-400 hover:text-white" onClick={() => setView('dashboard')}>
                  <Settings className="w-4 h-4 mr-1" /> {currentUser.name}
                </Button>
                <Button variant="ghost" size="sm" className="text-red-400 hover:text-red-300" onClick={logout}>
                  <LogOut className="w-4 h-4" />
                </Button>
              </div>
            ) : (
              <div className="flex gap-2">
                <Button variant="ghost" className="text-zinc-300 hover:text-white hover:bg-zinc-800" onClick={() => setView('login')}>
                  Sign In
                </Button>
                <Button className="bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-black font-semibold shadow-lg shadow-amber-500/25" onClick={() => setView('register')}>
                  Join Free
                </Button>
              </div>
            )}
          </div>

          {/* Mobile Menu Toggle */}
          <button className="md:hidden text-zinc-300" onClick={() => setMobileMenuOpen(!mobileMenuOpen)}>
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      <AnimatePresence>
        {mobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="md:hidden bg-black/95 border-t border-amber-500/20 overflow-hidden"
          >
            <div className="px-4 py-4 space-y-2">
              <MobileNavButton icon={<LayoutGrid className="w-5 h-5" />} label="Browse Talent" onClick={() => { setView('browse'); setMobileMenuOpen(false); }} />
              <MobileNavButton icon={<Clapperboard className="w-5 h-5" />} label="Auditions" onClick={() => { setView('auditions'); setMobileMenuOpen(false); }} />
              <MobileNavButton icon={<FileText className="w-5 h-5" />} label="Scripts" onClick={() => { setView('scripts'); setMobileMenuOpen(false); }} />
              {currentUser && (
                <>
                  <MobileNavButton icon={<Sparkles className="w-5 h-5" />} label="For You" onClick={() => { setView('recommendations'); setMobileMenuOpen(false); }} />
                  <MobileNavButton icon={<User className="w-5 h-5" />} label="My Dashboard" onClick={() => { setView('dashboard'); setMobileMenuOpen(false); }} />
                  <Separator className="bg-zinc-800 my-2" />
                  <MobileNavButton icon={<LogOut className="w-5 h-5 text-red-400" />} label="Sign Out" onClick={() => { logout(); setMobileMenuOpen(false); }} />
                </>
              )}
              {!currentUser && (
                <>
                  <Separator className="bg-zinc-800 my-2" />
                  <Button className="w-full bg-gradient-to-r from-amber-500 to-amber-600 text-black font-semibold" onClick={() => { setView('register'); setMobileMenuOpen(false); }}>
                    Join Free
                  </Button>
                </>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );

  const NavButton = ({ icon, label, onClick }: { icon: React.ReactNode; label: string; onClick: () => void }) => (
    <button onClick={onClick} className="px-3 py-2 text-sm text-zinc-400 hover:text-amber-400 hover:bg-zinc-800/50 rounded-lg transition-all flex items-center gap-1.5">
      {icon} {label}
    </button>
  );

  const MobileNavButton = ({ icon, label, onClick }: { icon: React.ReactNode; label: string; onClick: () => void }) => (
    <button onClick={onClick} className="w-full px-4 py-3 text-left text-zinc-300 hover:text-amber-400 hover:bg-zinc-800/50 rounded-xl transition-all flex items-center gap-3">
      {icon} <span>{label}</span>
    </button>
  );

  // ============================================================
  // FOOTER
  // ============================================================
  const Footer = () => (
    <footer className="bg-black border-t border-zinc-800 mt-auto">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="md:col-span-1">
            <div className="flex items-center gap-2 mb-4">
              <div className="w-8 h-8 bg-gradient-to-br from-amber-400 to-amber-600 rounded-lg flex items-center justify-center">
                <Film className="w-5 h-5 text-black" />
              </div>
              <span className="text-lg font-bold text-amber-400">FilmCast Hub</span>
            </div>
            <p className="text-zinc-500 text-sm">The #1 marketplace where film talent meets opportunity. Connect, showcase, and get discovered.</p>
          </div>
          <div>
            <h4 className="text-white font-semibold mb-3">For Talent</h4>
            <div className="space-y-2">
              <p className="text-zinc-500 text-sm hover:text-amber-400 cursor-pointer transition-colors">Create Profile</p>
              <p className="text-zinc-500 text-sm hover:text-amber-400 cursor-pointer transition-colors">Upload Reels</p>
              <p className="text-zinc-500 text-sm hover:text-amber-400 cursor-pointer transition-colors">Find Auditions</p>
              <p className="text-zinc-500 text-sm hover:text-amber-400 cursor-pointer transition-colors">Go Premium</p>
            </div>
          </div>
          <div>
            <h4 className="text-white font-semibold mb-3">For Industry</h4>
            <div className="space-y-2">
              <p className="text-zinc-500 text-sm hover:text-amber-400 cursor-pointer transition-colors">Post Auditions</p>
              <p className="text-zinc-500 text-sm hover:text-amber-400 cursor-pointer transition-colors">Find Writers</p>
              <p className="text-zinc-500 text-sm hover:text-amber-400 cursor-pointer transition-colors">Browse Talent</p>
              <p className="text-zinc-500 text-sm hover:text-amber-400 cursor-pointer transition-colors">Hire Crew</p>
            </div>
          </div>
          <div>
            <h4 className="text-white font-semibold mb-3">Support</h4>
            <div className="space-y-2">
              <p className="text-zinc-500 text-sm hover:text-amber-400 cursor-pointer transition-colors">Help Center</p>
              <p className="text-zinc-500 text-sm hover:text-amber-400 cursor-pointer transition-colors">Contact Us</p>
              <p className="text-zinc-500 text-sm hover:text-amber-400 cursor-pointer transition-colors">Privacy Policy</p>
              <p className="text-zinc-500 text-sm hover:text-amber-400 cursor-pointer transition-colors">Terms of Service</p>
            </div>
          </div>
        </div>
        <Separator className="bg-zinc-800 my-8" />
        <div className="flex flex-col sm:flex-row justify-between items-center gap-4">
          <p className="text-zinc-600 text-sm">2026 FilmCast Hub. All rights reserved.</p>
          <p className="text-zinc-600 text-sm">Made with passion for the film industry</p>
        </div>
      </div>
    </footer>
  );

  // ============================================================
  // HOME / LANDING PAGE
  // ============================================================
  const HomePage = () => (
    <div className="min-h-screen bg-black">
      {/* Hero Section */}
      <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
        {/* Animated Background */}
        <div className="absolute inset-0">
          <div className="absolute inset-0 bg-gradient-to-b from-amber-900/20 via-black to-black" />
          <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-amber-500/10 rounded-full blur-3xl animate-pulse" />
          <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-amber-600/5 rounded-full blur-3xl animate-pulse" style={{ animationDelay: '1s' }} />
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-gradient-radial from-amber-500/5 to-transparent rounded-full" />
        </div>

        <div className="relative z-10 max-w-5xl mx-auto px-4 sm:px-6 text-center pt-20">
          <motion.div initial={{ opacity: 0, y: 40 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.8 }}>
            <Badge className="mb-6 bg-amber-500/10 border-amber-500/30 text-amber-400 px-4 py-1.5 text-sm">
              <Sparkles className="w-3.5 h-3.5 mr-1" /> The #1 Film Industry Marketplace
            </Badge>
            <h1 className="text-5xl sm:text-6xl md:text-7xl lg:text-8xl font-black text-white leading-tight mb-6">
              Where <span className="bg-gradient-to-r from-amber-300 via-amber-400 to-yellow-500 bg-clip-text text-transparent">Film Talent</span><br />
              Meets <span className="bg-gradient-to-r from-amber-300 via-amber-400 to-yellow-500 bg-clip-text text-transparent">Opportunity</span>
            </h1>
            <p className="text-lg sm:text-xl text-zinc-400 max-w-2xl mx-auto mb-10 leading-relaxed">
              Actors, directors, producers, writers, and crew — showcase your reels, find auditions, 
              sell scripts, and connect with the people who make movies happen.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button size="lg" className="bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-black font-bold text-lg px-8 py-6 shadow-2xl shadow-amber-500/30 hover:shadow-amber-500/50 transition-all" onClick={() => setView('register')}>
                <UserPlus className="w-5 h-5 mr-2" /> Create Your Profile — Free
              </Button>
              <Button size="lg" variant="outline" className="border-zinc-700 text-zinc-300 hover:bg-zinc-800 hover:text-white text-lg px-8 py-6" onClick={() => setView('browse')}>
                <Eye className="w-5 h-5 mr-2" /> Browse Talent
              </Button>
            </div>
          </motion.div>

          {/* Trust badges */}
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.6 }} className="mt-16 flex flex-wrap justify-center gap-8">
            {[
              { icon: <Users className="w-5 h-5" />, label: '10,000+ Members' },
              { icon: <Clapperboard className="w-5 h-5" />, label: '500+ Auditions' },
              { icon: <FileText className="w-5 h-5" />, label: '1,000+ Scripts' },
              { icon: <Globe className="w-5 h-5" />, label: 'Global Reach' },
            ].map((item, i) => (
              <div key={i} className="flex items-center gap-2 text-zinc-500">
                {item.icon} <span className="text-sm">{item.label}</span>
              </div>
            ))}
          </motion.div>
        </div>

        {/* Scroll indicator */}
        <motion.div className="absolute bottom-8 left-1/2 -translate-x-1/2" animate={{ y: [0, 10, 0] }} transition={{ repeat: Infinity, duration: 2 }}>
          <div className="w-6 h-10 border-2 border-zinc-600 rounded-full flex justify-center pt-2">
            <div className="w-1 h-2 bg-amber-400 rounded-full" />
          </div>
        </motion.div>
      </section>

      {/* How It Works */}
      <section className="py-24 bg-zinc-950">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <motion.div {...fadeUp} className="text-center mb-16">
            <h2 className="text-3xl sm:text-4xl font-bold text-white mb-4">How It Works</h2>
            <p className="text-zinc-400 text-lg">Three simple steps to launch your film career</p>
          </motion.div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              { step: '01', icon: <UserPlus className="w-8 h-8" />, title: 'Create Profile', desc: 'Sign up in seconds. Choose your role — actor, director, producer, writer, or crew member. Set your rates, upload your reel, and showcase your talent.' },
              { step: '02', icon: <Upload className="w-8 h-8" />, title: 'Showcase Work', desc: 'Upload your portfolio — films, monologues, demo reels, scripts. List your experience, skills, and contact info. Go premium for featured placement.' },
              { step: '03', icon: <TrendingUp className="w-8 h-8" />, title: 'Get Discovered', desc: 'Our smart algorithm matches you with relevant auditions, connects writers with producers, and helps crew find their next project.' },
            ].map((item, i) => (
              <motion.div key={i} initial={{ opacity: 0, y: 30 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.15 }} className="relative">
                <Card className="bg-zinc-900/50 border-zinc-800 hover:border-amber-500/30 transition-all duration-300 h-full group">
                  <CardContent className="p-8">
                    <div className="text-5xl font-black text-amber-500/10 mb-4">{item.step}</div>
                    <div className="w-14 h-14 bg-amber-500/10 rounded-2xl flex items-center justify-center text-amber-400 mb-4 group-hover:bg-amber-500/20 transition-colors">
                      {item.icon}
                    </div>
                    <h3 className="text-xl font-bold text-white mb-3">{item.title}</h3>
                    <p className="text-zinc-400 leading-relaxed">{item.desc}</p>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Roles Section */}
      <section className="py-24 bg-black">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <motion.div {...fadeUp} className="text-center mb-16">
            <h2 className="text-3xl sm:text-4xl font-bold text-white mb-4">Built For Every Role</h2>
            <p className="text-zinc-400 text-lg">Whether you're in front of or behind the camera, we've got you covered</p>
          </motion.div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {[
              { icon: <Camera className="w-7 h-7" />, role: 'Actors', desc: 'Upload reels, monologues, and headshots. List your experience, rates, and get discovered by casting directors.', color: 'from-rose-500 to-pink-600' },
              { icon: <Clapperboard className="w-7 h-7" />, role: 'Directors', desc: 'Show your directorial reel, post audition announcements, find the perfect cast for your next project.', color: 'from-violet-500 to-purple-600' },
              { icon: <Briefcase className="w-7 h-7" />, role: 'Producers', desc: 'Post casting calls, browse writers and scripts, find the talent to bring your vision to life.', color: 'from-emerald-500 to-green-600' },
              { icon: <PenTool className="w-7 h-7" />, role: 'Writers', desc: 'Post your scripts for producers to discover. Set your rates, share your synopsis, get optioned.', color: 'from-sky-500 to-blue-600' },
              { icon: <Wrench className="w-7 h-7" />, role: 'Crew Members', desc: 'Cinematographers, editors, sound engineers — showcase your work and find your next gig.', color: 'from-orange-500 to-amber-600' },
              { icon: <Sparkles className="w-7 h-7" />, role: 'All creatives', desc: 'Go premium for featured placement, priority in recommendations, and a verified badge on your profile.', color: 'from-amber-400 to-yellow-500' },
            ].map((item, i) => (
              <motion.div key={i} initial={{ opacity: 0, scale: 0.95 }} whileInView={{ opacity: 1, scale: 1 }} viewport={{ once: true }} transition={{ delay: i * 0.1 }}>
                <Card className="bg-zinc-900/50 border-zinc-800 hover:border-amber-500/30 transition-all duration-300 h-full group cursor-pointer hover:-translate-y-1">
                  <CardContent className="p-6">
                    <div className={`w-14 h-14 bg-gradient-to-br ${item.color} rounded-2xl flex items-center justify-center text-white mb-4 shadow-lg group-hover:scale-110 transition-transform`}>
                      {item.icon}
                    </div>
                    <h3 className="text-lg font-bold text-white mb-2">{item.role}</h3>
                    <p className="text-zinc-400 text-sm leading-relaxed">{item.desc}</p>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Premium Section */}
      <section className="py-24 bg-gradient-to-b from-black via-zinc-950 to-black">
        <div className="max-w-4xl mx-auto px-4 sm:px-6">
          <motion.div {...fadeUp} className="text-center">
            <Badge className="mb-4 bg-amber-500/10 border-amber-500/30 text-amber-400">
              <Crown className="w-3.5 h-3.5 mr-1" /> Premium Membership
            </Badge>
            <h2 className="text-3xl sm:text-4xl font-bold text-white mb-4">Go Premium for Just $1</h2>
            <p className="text-zinc-400 text-lg mb-12 max-w-2xl mx-auto">
              One dollar. Unlimited opportunity. Stand out from thousands of talent profiles and get discovered faster.
            </p>
          </motion.div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <Card className="bg-zinc-900/50 border-zinc-800">
              <CardHeader>
                <CardTitle className="text-zinc-400 text-lg">Free Plan</CardTitle>
                <CardDescription>Get started with the basics</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="text-3xl font-bold text-white">$0<span className="text-zinc-500 text-base font-normal">/forever</span></div>
                <Separator className="bg-zinc-800" />
                {['Basic profile', 'Upload 3 works', 'Browse auditions', 'Search talent', 'Standard listing'].map((f, i) => (
                  <div key={i} className="flex items-center gap-2 text-zinc-400 text-sm"><CheckCircle2 className="w-4 h-4 text-zinc-500" /> {f}</div>
                ))}
                <Button className="w-full mt-4" variant="outline" onClick={() => setView('register')}>Get Started</Button>
              </CardContent>
            </Card>
            <Card className="bg-gradient-to-b from-amber-500/10 to-zinc-900/50 border-amber-500/30 relative overflow-hidden">
              <div className="absolute top-4 right-4">
                <Badge className="bg-amber-500 text-black font-bold">BEST VALUE</Badge>
              </div>
              <CardHeader>
                <CardTitle className="text-amber-400 text-lg flex items-center gap-2"><Crown className="w-5 h-5" /> Premium</CardTitle>
                <CardDescription>Everything you need to get discovered</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="text-3xl font-bold text-white">$1<span className="text-zinc-500 text-base font-normal">/one-time</span></div>
                <Separator className="bg-amber-500/20" />
                {['Featured profile badge', 'Unlimited uploads', 'Priority in search results', 'Monologue uploads', 'Smart recommendations', 'Direct contact access', 'Early audition access'].map((f, i) => (
                  <div key={i} className="flex items-center gap-2 text-amber-200 text-sm"><CheckCircle2 className="w-4 h-4 text-amber-400" /> {f}</div>
                ))}
                <Button className="w-full mt-4 bg-gradient-to-r from-amber-500 to-amber-600 text-black font-bold hover:from-amber-400 hover:to-amber-500" onClick={() => setView('register')}>
                  Go Premium — $1
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-24 bg-black">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 text-center">
          <motion.div {...fadeUp}>
            <h2 className="text-3xl sm:text-4xl font-bold text-white mb-6">Ready to Get Discovered?</h2>
            <p className="text-zinc-400 text-lg mb-8">Join thousands of film professionals already showcasing their talent on FilmCast Hub.</p>
            <Button size="lg" className="bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-black font-bold text-lg px-10 py-7 shadow-2xl shadow-amber-500/30" onClick={() => setView('register')}>
              Create Your Free Profile Now
            </Button>
          </motion.div>
        </div>
      </section>
    </div>
  );

  // ============================================================
  // LOGIN / REGISTER
  // ============================================================
  const AuthView = ({ mode }: { mode: 'login' | 'register' }) => {
    const [form, setForm] = useState({ email: '', password: '', name: '', role: 'actor', phone: '' });
    const [error, setError] = useState('');
    const [isLoading, setIsLoading] = useState(false);

    const handleSubmit = async (e: React.FormEvent) => {
      e.preventDefault();
      setIsLoading(true);
      setError('');
      try {
        const endpoint = mode === 'register' ? '/api/auth/register' : '/api/auth/login';
        const body = mode === 'register'
          ? { email: form.email, password: form.password, name: form.name, role: form.role, phone: form.phone }
          : { email: form.email, password: form.password };
        const data = await api(endpoint, { method: 'POST', body: JSON.stringify(body) });
        if (data.success) {
          const userData = { ...data.user, password: '' };
          setCurrentUser(userData);
          localStorage.setItem('filmcast_user', JSON.stringify(userData));
          setView('dashboard');
        } else {
          setError(data.error || 'Something went wrong');
        }
      } catch {
        setError('Connection error. Please try again.');
      }
      setIsLoading(false);
    };

    return (
      <div className="min-h-screen bg-black flex items-center justify-center pt-16 px-4">
        <div className="absolute inset-0">
          <div className="absolute top-1/3 left-1/3 w-96 h-96 bg-amber-500/5 rounded-full blur-3xl" />
          <div className="absolute bottom-1/3 right-1/3 w-96 h-96 bg-amber-600/5 rounded-full blur-3xl" />
        </div>
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="relative w-full max-w-md">
          <Card className="bg-zinc-900/80 border-zinc-800 backdrop-blur-xl shadow-2xl">
            <CardHeader className="text-center pb-2">
              <div className="w-16 h-16 bg-gradient-to-br from-amber-400 to-amber-600 rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-lg shadow-amber-500/30">
                <Film className="w-9 h-9 text-black" />
              </div>
              <CardTitle className="text-2xl font-bold text-white">
                {mode === 'register' ? 'Join FilmCast Hub' : 'Welcome Back'}
              </CardTitle>
              <CardDescription className="text-zinc-400">
                {mode === 'register' ? 'Create your free profile and start getting discovered' : 'Sign in to your account'}
              </CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-4">
                {mode === 'register' && (
                  <>
                    <div>
                      <Label className="text-zinc-300">Full Name</Label>
                      <Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} required placeholder="John Doe" className="bg-zinc-800 border-zinc-700 text-white placeholder:text-zinc-500" />
                    </div>
                    <div>
                      <Label className="text-zinc-300">I am a...</Label>
                      <Select value={form.role} onValueChange={(v) => setForm({ ...form, role: v })}>
                        <SelectTrigger className="bg-zinc-800 border-zinc-700 text-white"><SelectValue /></SelectTrigger>
                        <SelectContent className="bg-zinc-800 border-zinc-700">
                          <SelectItem value="actor">Actor / Actress</SelectItem>
                          <SelectItem value="director">Director</SelectItem>
                          <SelectItem value="producer">Producer</SelectItem>
                          <SelectItem value="writer">Writer / Screenwriter</SelectItem>
                          <SelectItem value="crew">Crew Member</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label className="text-zinc-300">Phone (optional)</Label>
                      <Input value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} placeholder="+1 234 567 890" className="bg-zinc-800 border-zinc-700 text-white placeholder:text-zinc-500" />
                    </div>
                  </>
                )}
                <div>
                  <Label className="text-zinc-300">Email</Label>
                  <Input type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} required placeholder="you@example.com" className="bg-zinc-800 border-zinc-700 text-white placeholder:text-zinc-500" />
                </div>
                <div>
                  <Label className="text-zinc-300">Password</Label>
                  <Input type="password" value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} required placeholder="Min 6 characters" minLength={6} className="bg-zinc-800 border-zinc-700 text-white placeholder:text-zinc-500" />
                </div>
                {error && <p className="text-red-400 text-sm">{error}</p>}
                <Button type="submit" className="w-full bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-black font-bold" disabled={isLoading}>
                  {isLoading ? 'Please wait...' : mode === 'register' ? 'Create Account' : 'Sign In'}
                </Button>
              </form>
              <div className="mt-6 text-center">
                <p className="text-zinc-500 text-sm">
                  {mode === 'register' ? 'Already have an account?' : "Don't have an account?"}{' '}
                  <button onClick={() => setView(mode === 'register' ? 'login' : 'register')} className="text-amber-400 hover:text-amber-300 font-medium">
                    {mode === 'register' ? 'Sign In' : 'Sign Up'}
                  </button>
                </p>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    );
  };

  // ============================================================
  // BROWSE MEMBERS
  // ============================================================
  const BrowseView = () => {
    const [members, setMembers] = useState<User[]>([]);
    const [searching, setSearching] = useState(false);
    const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');

    const fetchMembers = useCallback(async () => {
      setSearching(true);
      try {
        const params = new URLSearchParams();
        if (selectedRole !== 'all') params.set('role', selectedRole);
        if (searchQuery) params.set('search', searchQuery);
        params.set('limit', '50');
        const data = await api(`/api/members?${params}`);
        if (data.success) setMembers(data.members);
      } catch { /* silent */ }
      setSearching(false);
    }, [selectedRole, searchQuery]);

    useEffect(() => { fetchMembers(); }, [fetchMembers]);

    const roleFilters = ['all', 'actor', 'director', 'producer', 'writer', 'crew'];

    return (
      <div className="min-h-screen bg-black pt-20 pb-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          {/* Header */}
          <motion.div {...fadeUp} className="mb-8">
            <h1 className="text-3xl sm:text-4xl font-bold text-white mb-2">Browse Talent</h1>
            <p className="text-zinc-400">Discover film professionals from around the world</p>
          </motion.div>

          {/* Search & Filters */}
          <div className="flex flex-col sm:flex-row gap-4 mb-8">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-zinc-500" />
              <Input
                placeholder="Search by name, skills, or location..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 bg-zinc-900 border-zinc-800 text-white placeholder:text-zinc-500 h-12"
              />
            </div>
            <div className="flex gap-2 items-center">
              <div className="flex gap-1 overflow-x-auto pb-1">
                {roleFilters.map((role) => (
                  <button
                    key={role}
                    onClick={() => setSelectedRole(role)}
                    className={`px-3 py-1.5 rounded-lg text-sm font-medium whitespace-nowrap transition-all ${
                      selectedRole === role
                        ? 'bg-amber-500 text-black'
                        : 'bg-zinc-900 text-zinc-400 hover:bg-zinc-800 hover:text-white'
                    }`}
                  >
                    {role === 'all' ? 'All Roles' : role.charAt(0).toUpperCase() + role.slice(1) + 's'}
                  </button>
                ))}
              </div>
              <div className="flex border border-zinc-800 rounded-lg overflow-hidden">
                <button onClick={() => setViewMode('grid')} className={`p-2 ${viewMode === 'grid' ? 'bg-amber-500 text-black' : 'bg-zinc-900 text-zinc-400'}`}><LayoutGrid className="w-4 h-4" /></button>
                <button onClick={() => setViewMode('list')} className={`p-2 ${viewMode === 'list' ? 'bg-amber-500 text-black' : 'bg-zinc-900 text-zinc-400'}`}><List className="w-4 h-4" /></button>
              </div>
            </div>
          </div>

          {/* Results */}
          {searching ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {[1, 2, 3, 4, 5, 6].map((i) => (
                <Card key={i} className="bg-zinc-900/50 border-zinc-800"><CardContent className="p-6"><Skeleton className="h-48 w-full bg-zinc-800 rounded-xl mb-4" /><Skeleton className="h-5 w-3/4 bg-zinc-800 mb-2" /><Skeleton className="h-4 w-1/2 bg-zinc-800" /></CardContent></Card>
              ))}
            </div>
          ) : members.length === 0 ? (
            <div className="text-center py-20">
              <Users className="w-16 h-16 text-zinc-700 mx-auto mb-4" />
              <h3 className="text-xl text-zinc-400 mb-2">No talent found</h3>
              <p className="text-zinc-600">Try adjusting your search or filters</p>
            </div>
          ) : viewMode === 'grid' ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {members.map((member, i) => (
                <motion.div key={member.id} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.05 }}>
                  <MemberCard member={member} onClick={() => { setCurrentUser((prev) => prev); }} compact />
                </motion.div>
              ))}
            </div>
          ) : (
            <div className="space-y-4">
              {members.map((member) => (
                <MemberListItem key={member.id} member={member} />
              ))}
            </div>
          )}
        </div>
      </div>
    );
  };

  // ============================================================
  // MEMBER CARD
  // ============================================================
  const MemberCard = ({ member, onClick, compact }: { member: User; onClick?: () => void; compact?: boolean }) => (
    <Card className="bg-zinc-900/50 border-zinc-800 hover:border-amber-500/30 transition-all duration-300 h-full group cursor-pointer overflow-hidden relative">
      {member.isPremium && (
        <div className="absolute top-3 right-3 z-10">
          <Badge className="bg-amber-500 text-black font-bold shadow-lg shadow-amber-500/30"><Crown className="w-3 h-3 mr-1" />PRO</Badge>
        </div>
      )}
      <div className="h-48 bg-gradient-to-br from-zinc-800 to-zinc-900 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-t from-zinc-900 to-transparent" />
        <div className="absolute bottom-4 left-4">
          <Avatar className="w-16 h-16 border-3 border-amber-500/50 shadow-lg">
            <AvatarFallback className="bg-gradient-to-br from-amber-500 to-amber-700 text-black text-lg font-bold">
              {member.name?.split(' ').map(n => n[0]).join('').slice(0, 2)}
            </AvatarFallback>
          </Avatar>
        </div>
        <div className="absolute bottom-4 right-4">
          <Badge className="bg-zinc-800/80 text-zinc-300 border-zinc-700 backdrop-blur-sm capitalize">
            {member.role}
          </Badge>
        </div>
      </div>
      <CardContent className="p-5">
        <h3 className="text-lg font-bold text-white group-hover:text-amber-400 transition-colors">{member.name}</h3>
        {member.location && <p className="text-zinc-500 text-sm flex items-center gap-1 mt-1"><MapPin className="w-3.5 h-3.5" /> {member.location}</p>}
        {member.chargingPrice && (
          <p className="text-amber-400 font-semibold text-sm flex items-center gap-1 mt-2"><DollarSign className="w-3.5 h-3.5" /> {member.chargingPrice}</p>
        )}
        {member.skills && (
          <div className="flex flex-wrap gap-1.5 mt-3">
            {member.skills.split(',').slice(0, 4).map((skill, i) => (
              <Badge key={i} variant="outline" className="border-zinc-700 text-zinc-400 text-xs">{skill.trim()}</Badge>
            ))}
          </div>
        )}
        <div className="flex items-center gap-3 mt-4 text-zinc-500 text-xs">
          {member.email && <span className="flex items-center gap-1"><Mail className="w-3 h-3" /> Email</span>}
          {member.phone && <span className="flex items-center gap-1"><Phone className="w-3 h-3" /> Phone</span>}
          {member.reelUrl && <span className="flex items-center gap-1"><Play className="w-3 h-3" /> Reel</span>}
        </div>
      </CardContent>
    </Card>
  );

  const MemberListItem = ({ member }: { member: User }) => (
    <Card className="bg-zinc-900/50 border-zinc-800 hover:border-amber-500/30 transition-all cursor-pointer">
      <CardContent className="p-4 flex items-center gap-4">
        <Avatar className="w-14 h-14 border-2 border-amber-500/30 shrink-0">
          <AvatarFallback className="bg-gradient-to-br from-amber-500 to-amber-700 text-black font-bold">
            {member.name?.split(' ').map(n => n[0]).join('').slice(0, 2)}
          </AvatarFallback>
        </Avatar>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2">
            <h3 className="font-bold text-white truncate">{member.name}</h3>
            {member.isPremium && <Badge className="bg-amber-500 text-black text-xs shrink-0"><Crown className="w-2.5 h-2.5" />PRO</Badge>}
          </div>
          <div className="flex items-center gap-3 mt-1 text-sm text-zinc-500">
            <span className="capitalize">{member.role}</span>
            {member.location && <span><MapPin className="w-3 h-3 inline" /> {member.location}</span>}
            {member.chargingPrice && <span className="text-amber-400"><DollarSign className="w-3 h-3 inline" />{member.chargingPrice}</span>}
          </div>
        </div>
        <ChevronRight className="w-5 h-5 text-zinc-600 shrink-0" />
      </CardContent>
    </Card>
  );

  // ============================================================
  // PROFILE VIEW (Viewing someone else's profile)
  // ============================================================
  const ProfileView = () => (
    <div className="min-h-screen bg-black pt-20 pb-12">
      <div className="max-w-4xl mx-auto px-4 sm:px-6">
        <Button variant="ghost" className="text-zinc-400 hover:text-white mb-6" onClick={() => setView('browse')}>
          <ArrowLeft className="w-4 h-4 mr-2" /> Back to Browse
        </Button>
        <Card className="bg-zinc-900/50 border-zinc-800 overflow-hidden">
          {/* Cover */}
          <div className="h-48 bg-gradient-to-r from-amber-600/20 via-zinc-800 to-zinc-900 relative">
            <div className="absolute inset-0 bg-gradient-to-t from-zinc-900 to-transparent" />
          </div>
          <CardContent className="p-6 -mt-12 relative z-10">
            <div className="flex flex-col sm:flex-row gap-6">
              <Avatar className="w-24 h-24 border-4 border-zinc-900 shadow-xl shrink-0">
                <AvatarFallback className="bg-gradient-to-br from-amber-500 to-amber-700 text-black text-2xl font-bold">??</AvatarFallback>
              </Avatar>
              <div className="flex-1">
                <div className="flex items-center gap-3">
                  <h1 className="text-2xl font-bold text-white">Profile Name</h1>
                  <Badge className="bg-amber-500 text-black"><Crown className="w-3 h-3 mr-1" />PRO</Badge>
                </div>
                <p className="text-zinc-400 capitalize mt-1">Actor / Actress</p>
                <div className="flex flex-wrap gap-4 mt-3 text-sm text-zinc-400">
                  <span className="flex items-center gap-1"><MapPin className="w-4 h-4" /> Lagos, Nigeria</span>
                  <span className="flex items-center gap-1"><Mail className="w-4 h-4" /> email@example.com</span>
                  <span className="flex items-center gap-1"><Phone className="w-4 h-4" /> +234 123 456</span>
                  <span className="flex items-center gap-1 text-amber-400"><DollarSign className="w-4 h-4" /> $500/day</span>
                </div>
              </div>
            </div>
            <Separator className="bg-zinc-800 my-6" />
            <p className="text-zinc-300 leading-relaxed mb-6">This is a sample profile. Sign up and create your own complete profile with reels, works, monologues, and more.</p>
            <div className="flex gap-3">
              <Button className="bg-gradient-to-r from-amber-500 to-amber-600 text-black font-semibold"><Heart className="w-4 h-4 mr-2" />Save</Button>
              <Button variant="outline" className="border-zinc-700 text-zinc-300"><Mail className="w-4 h-4 mr-2" />Contact</Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );

  // ============================================================
  // DASHBOARD (User's own profile management)
  // ============================================================
  const DashboardView = () => {
    if (!currentUser) { setView('login'); return null; }
    return (
      <div className="min-h-screen bg-black pt-20 pb-12">
        <div className="max-w-6xl mx-auto px-4 sm:px-6">
          <motion.div {...fadeUp}>
            <div className="flex items-center gap-3 mb-8">
              <h1 className="text-3xl font-bold text-white">My Dashboard</h1>
              <Badge className={currentUser.isPremium ? 'bg-amber-500 text-black' : 'bg-zinc-800 text-zinc-400'}>
                {currentUser.isPremium ? <><Crown className="w-3 h-3 mr-1" />PRO</> : 'Free Plan'}
              </Badge>
            </div>
          </motion.div>
          <Tabs defaultValue="profile" className="space-y-6">
            <TabsList className="bg-zinc-900 border-zinc-800 w-full sm:w-auto overflow-x-auto">
              <TabsTrigger value="profile" className="data-[state=active]:bg-amber-500 data-[state=active]:text-black">Profile</TabsTrigger>
              <TabsTrigger value="works" className="data-[state=active]:bg-amber-500 data-[state=active]:text-black">Works</TabsTrigger>
              {(currentUser.role === 'actor') && (
                <TabsTrigger value="monologues" className="data-[state=active]:bg-amber-500 data-[state=active]:text-black">Monologues</TabsTrigger>
              )}
              {(currentUser.role === 'producer' || currentUser.role === 'director') && (
                <TabsTrigger value="myauditions" className="data-[state=active]:bg-amber-500 data-[state=active]:text-black">My Auditions</TabsTrigger>
              )}
              {currentUser.role === 'writer' && (
                <TabsTrigger value="myscripts" className="data-[state=active]:bg-amber-500 data-[state=active]:text-black">My Scripts</TabsTrigger>
              )}
              <TabsTrigger value="premium" className="data-[state=active]:bg-amber-500 data-[state=active]:text-black">
                <Crown className="w-3.5 h-3.5 mr-1" />
              </TabsTrigger>
            </TabsList>

            <TabsContent value="profile"><ProfileEditor /></TabsContent>
            <TabsContent value="works"><WorksManager /></TabsContent>
            <TabsContent value="monologues"><MonologuesManager /></TabsContent>
            <TabsContent value="myauditions"><MyAuditionsManager /></TabsContent>
            <TabsContent value="myscripts"><MyScriptsManager /></TabsContent>
            <TabsContent value="premium"><PremiumUpgrade /></TabsContent>
          </Tabs>
        </div>
      </div>
    );
  };

  // ============================================================
  // PROFILE EDITOR
  // ============================================================
  const ProfileEditor = () => {
    const [form, setForm] = useState({
      name: currentUser?.name || '',
      phone: currentUser?.phone || '',
      bio: currentUser?.bio || '',
      reelUrl: currentUser?.reelUrl || '',
      chargingPrice: currentUser?.chargingPrice || '',
      location: currentUser?.location || '',
      skills: currentUser?.skills || '',
    });
    const [saving, setSaving] = useState(false);
    const [saved, setSaved] = useState(false);

    const handleSave = async () => {
      setSaving(true);
      try {
        const data = await api('/api/profile', {
          method: 'PUT',
          body: JSON.stringify({ userId: currentUser?.id, ...form }),
        });
        if (data.success) {
          setSaved(true);
          setTimeout(() => setSaved(false), 3000);
          const updated = { ...currentUser, ...form };
          setCurrentUser(updated);
          localStorage.setItem('filmcast_user', JSON.stringify(updated));
        }
      } catch { /* silent */ }
      setSaving(false);
    };

    return (
      <Card className="bg-zinc-900/50 border-zinc-800">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2"><User className="w-5 h-5" /> Edit Profile</CardTitle>
          <CardDescription>Keep your profile updated to get discovered by the right people</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <Label className="text-zinc-300">Full Name</Label>
              <Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} className="bg-zinc-800 border-zinc-700 text-white" />
            </div>
            <div>
              <Label className="text-zinc-300">Phone</Label>
              <Input value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} placeholder="+1 234 567 890" className="bg-zinc-800 border-zinc-700 text-white" />
            </div>
          </div>
          <div>
            <Label className="text-zinc-300">Location</Label>
            <Input value={form.location} onChange={(e) => setForm({ ...form, location: e.target.value })} placeholder="Lagos, Nigeria" className="bg-zinc-800 border-zinc-700 text-white" />
          </div>
          <div>
            <Label className="text-zinc-300">Bio / About You</Label>
            <Textarea value={form.bio} onChange={(e) => setForm({ ...form, bio: e.target.value })} rows={4} placeholder="Tell people about yourself, your experience, and what you're looking for..." className="bg-zinc-800 border-zinc-700 text-white placeholder:text-zinc-500" />
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <Label className="text-zinc-300">Demo Reel URL</Label>
              <Input value={form.reelUrl} onChange={(e) => setForm({ ...form, reelUrl: e.target.value })} placeholder="https://youtube.com/watch?v=..." className="bg-zinc-800 border-zinc-700 text-white" />
            </div>
            <div>
              <Label className="text-zinc-300">Charging Rate</Label>
              <Input value={form.chargingPrice} onChange={(e) => setForm({ ...form, chargingPrice: e.target.value })} placeholder="$500/day or $2000/project" className="bg-zinc-800 border-zinc-700 text-white" />
            </div>
          </div>
          <div>
            <Label className="text-zinc-300">Skills (comma-separated)</Label>
            <Input value={form.skills} onChange={(e) => setForm({ ...form, skills: e.target.value })} placeholder="Method Acting, Stunts, Dialects, Improv" className="bg-zinc-800 border-zinc-700 text-white" />
          </div>
          <div className="flex items-center gap-3 pt-2">
            <Button onClick={handleSave} disabled={saving} className="bg-gradient-to-r from-amber-500 to-amber-600 text-black font-semibold">
              {saving ? 'Saving...' : 'Save Profile'}
            </Button>
            {saved && <span className="text-green-400 text-sm flex items-center gap-1"><CheckCircle2 className="w-4 h-4" /> Profile saved!</span>}
          </div>
        </CardContent>
      </Card>
    );
  };

  // ============================================================
  // WORKS MANAGER
  // ============================================================
  const WorksManager = () => {
    const [works, setWorks] = useState<Work[]>([]);
    const [showAdd, setShowAdd] = useState(false);
    const [form, setForm] = useState({ title: '', type: 'film', role: '', year: '', description: '', imageUrl: '', videoUrl: '' });

    const fetchWorks = async () => {
      if (!currentUser) return;
      const data = await api(`/api/works?userId=${currentUser.id}`);
      if (data.success) setWorks(data.works);
    };

    useEffect(() => { fetchWorks(); }, []);

    const handleAdd = async () => {
      if (!currentUser || !form.title) return;
      await api('/api/works', { method: 'POST', body: JSON.stringify({ userId: currentUser.id, ...form }) });
      setForm({ title: '', type: 'film', role: '', year: '', description: '', imageUrl: '', videoUrl: '' });
      setShowAdd(false);
      fetchWorks();
    };

    const handleDelete = async (workId: string) => {
      await api(`/api/works?workId=${workId}`, { method: 'DELETE' });
      fetchWorks();
    };

    return (
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <h2 className="text-xl font-bold text-white">My Works & Portfolio</h2>
          <Button onClick={() => setShowAdd(!showAdd)} className="bg-amber-500 text-black font-semibold">
            <Plus className="w-4 h-4 mr-2" /> Add Work
          </Button>
        </div>

        <AnimatePresence>
          {showAdd && (
            <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: 'auto' }} exit={{ opacity: 0, height: 0 }}>
              <Card className="bg-zinc-900/50 border-amber-500/30">
                <CardHeader><CardTitle className="text-white">Add New Work</CardTitle></CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div><Label className="text-zinc-300">Title</Label><Input value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} className="bg-zinc-800 border-zinc-700 text-white" /></div>
                    <div><Label className="text-zinc-300">Type</Label>
                      <Select value={form.type} onValueChange={(v) => setForm({ ...form, type: v })}>
                        <SelectTrigger className="bg-zinc-800 border-zinc-700 text-white"><SelectValue /></SelectTrigger>
                        <SelectContent className="bg-zinc-800 border-zinc-700">
                          <SelectItem value="film">Film</SelectItem><SelectItem value="tv">TV Series</SelectItem><SelectItem value="theater">Theater</SelectItem><SelectItem value="commercial">Commercial</SelectItem><SelectItem value="music_video">Music Video</SelectItem><SelectItem value="short">Short Film</SelectItem><SelectItem value="documentary">Documentary</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div><Label className="text-zinc-300">Your Role</Label><Input value={form.role} onChange={(e) => setForm({ ...form, role: e.target.value })} placeholder="Lead Actor, Director, etc." className="bg-zinc-800 border-zinc-700 text-white" /></div>
                    <div><Label className="text-zinc-300">Year</Label><Input value={form.year} onChange={(e) => setForm({ ...form, year: e.target.value })} placeholder="2024" className="bg-zinc-800 border-zinc-700 text-white" /></div>
                  </div>
                  <div><Label className="text-zinc-300">Description</Label><Textarea value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} rows={2} className="bg-zinc-800 border-zinc-700 text-white" /></div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div><Label className="text-zinc-300">Image URL</Label><Input value={form.imageUrl} onChange={(e) => setForm({ ...form, imageUrl: e.target.value })} className="bg-zinc-800 border-zinc-700 text-white" /></div>
                    <div><Label className="text-zinc-300">Video URL</Label><Input value={form.videoUrl} onChange={(e) => setForm({ ...form, videoUrl: e.target.value })} className="bg-zinc-800 border-zinc-700 text-white" /></div>
                  </div>
                  <div className="flex gap-2">
                    <Button onClick={handleAdd} className="bg-amber-500 text-black font-semibold">Save Work</Button>
                    <Button variant="ghost" className="text-zinc-400" onClick={() => setShowAdd(false)}>Cancel</Button>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          )}
        </AnimatePresence>

        {works.length === 0 ? (
          <Card className="bg-zinc-900/50 border-zinc-800 p-8 text-center">
            <Video className="w-12 h-12 text-zinc-700 mx-auto mb-3" />
            <h3 className="text-zinc-400 mb-1">No works yet</h3>
            <p className="text-zinc-600 text-sm">Add your first film, show, or project to showcase your experience</p>
          </Card>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {works.map((work) => (
              <Card key={work.id} className="bg-zinc-900/50 border-zinc-800 overflow-hidden group">
                <div className="h-36 bg-gradient-to-br from-zinc-800 to-zinc-900 relative flex items-center justify-center">
                  {work.videoUrl ? <Play className="w-10 h-10 text-amber-400" /> : <Film className="w-10 h-10 text-zinc-700" />}
                  <Badge className="absolute top-2 right-2 bg-black/60 text-zinc-300 text-xs capitalize">{work.type.replace('_', ' ')}</Badge>
                </div>
                <CardContent className="p-4">
                  <h3 className="font-bold text-white text-sm">{work.title}</h3>
                  {work.role && <p className="text-amber-400 text-xs mt-1">{work.role}</p>}
                  {work.year && <p className="text-zinc-500 text-xs">{work.year}</p>}
                  <div className="flex justify-end mt-2">
                    <Button variant="ghost" size="sm" className="text-red-400 hover:text-red-300 h-8" onClick={() => handleDelete(work.id)}>Delete</Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    );
  };

  // ============================================================
  // MONOLOGUES MANAGER (Actors)
  // ============================================================
  const MonologuesManager = () => {
    const [monologues, setMonologues] = useState<Monologue[]>([]);
    const [showAdd, setShowAdd] = useState(false);
    const [form, setForm] = useState({ title: '', genre: 'drama', description: '', videoUrl: '' });

    const fetchMonologues = async () => {
      if (!currentUser) return;
      const data = await api(`/api/monologues?userId=${currentUser.id}`);
      if (data.success) setMonologues(data.monologues);
    };

    useEffect(() => { fetchMonologues(); }, []);

    const handleAdd = async () => {
      if (!currentUser || !form.title) return;
      await api('/api/monologues', { method: 'POST', body: JSON.stringify({ userId: currentUser.id, ...form }) });
      setForm({ title: '', genre: 'drama', description: '', videoUrl: '' });
      setShowAdd(false);
      fetchMonologues();
    };

    const handleDelete = async (id: string) => {
      await api(`/api/monologues?monologueId=${id}`, { method: 'DELETE' });
      fetchMonologues();
    };

    return (
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <h2 className="text-xl font-bold text-white">My Monologues</h2>
          <Button onClick={() => setShowAdd(!showAdd)} className="bg-amber-500 text-black font-semibold">
            <Plus className="w-4 h-4 mr-2" /> Upload Monologue
          </Button>
        </div>

        <AnimatePresence>
          {showAdd && (
            <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: 'auto' }} exit={{ opacity: 0, height: 0 }}>
              <Card className="bg-zinc-900/50 border-amber-500/30">
                <CardHeader><CardTitle className="text-white">Upload Monologue</CardTitle></CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div><Label className="text-zinc-300">Title</Label><Input value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} className="bg-zinc-800 border-zinc-700 text-white" /></div>
                    <div><Label className="text-zinc-300">Genre</Label>
                      <Select value={form.genre} onValueChange={(v) => setForm({ ...form, genre: v })}>
                        <SelectTrigger className="bg-zinc-800 border-zinc-700 text-white"><SelectValue /></SelectTrigger>
                        <SelectContent className="bg-zinc-800 border-zinc-700">
                          <SelectItem value="drama">Drama</SelectItem><SelectItem value="comedy">Comedy</SelectItem><SelectItem value="classical">Classical</SelectItem><SelectItem value="contemporary">Contemporary</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  <div><Label className="text-zinc-300">Description</Label><Textarea value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} rows={2} className="bg-zinc-800 border-zinc-700 text-white" /></div>
                  <div><Label className="text-zinc-300">Video URL (YouTube, Vimeo, etc.)</Label><Input value={form.videoUrl} onChange={(e) => setForm({ ...form, videoUrl: e.target.value })} className="bg-zinc-800 border-zinc-700 text-white" /></div>
                  <div className="flex gap-2">
                    <Button onClick={handleAdd} className="bg-amber-500 text-black font-semibold">Upload</Button>
                    <Button variant="ghost" className="text-zinc-400" onClick={() => setShowAdd(false)}>Cancel</Button>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          )}
        </AnimatePresence>

        {monologues.length === 0 ? (
          <Card className="bg-zinc-900/50 border-zinc-800 p-8 text-center">
            <Video className="w-12 h-12 text-zinc-700 mx-auto mb-3" />
            <h3 className="text-zinc-400 mb-1">No monologues yet</h3>
            <p className="text-zinc-600 text-sm">Upload video monologues to showcase your acting range</p>
          </Card>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {monologues.map((m) => (
              <Card key={m.id} className="bg-zinc-900/50 border-zinc-800">
                <CardContent className="p-4">
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 bg-amber-500/10 rounded-xl flex items-center justify-center shrink-0"><Video className="w-6 h-6 text-amber-400" /></div>
                    <div className="flex-1 min-w-0">
                      <h3 className="font-bold text-white text-sm truncate">{m.title}</h3>
                      <Badge variant="outline" className="text-zinc-500 text-xs mt-1 capitalize">{m.genre}</Badge>
                    </div>
                    <Button variant="ghost" size="sm" className="text-red-400" onClick={() => handleDelete(m.id)}>Delete</Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    );
  };

  // ============================================================
  // AUDITIONS BOARD
  // ============================================================
  const AuditionsView = () => {
    const [auditions, setAuditions] = useState<Audition[]>([]);
    const [loading, setLoading] = useState(true);
    const [showPost, setShowPost] = useState(false);
    const [form, setForm] = useState({ title: '', description: '', roles: '', location: '', deadline: '', requirements: '' });

    const fetchAuditions = async () => {
      setLoading(true);
      const params = currentUser?.role === 'actor' ? '?role=actor' : '';
      const data = await api(`/api/auditions${params}`);
      if (data.success) setAuditions(data.auditions);
      setLoading(false);
    };

    useEffect(() => { fetchAuditions(); }, []);

    const handlePost = async () => {
      if (!currentUser || !form.title) return;
      await api('/api/auditions', { method: 'POST', body: JSON.stringify({ postedBy: currentUser.id, ...form }) });
      setForm({ title: '', description: '', roles: '', location: '', deadline: '', requirements: '' });
      setShowPost(false);
      fetchAuditions();
    };

    return (
      <div className="min-h-screen bg-black pt-20 pb-12">
        <div className="max-w-4xl mx-auto px-4 sm:px-6">
          <motion.div {...fadeUp}>
            <div className="flex items-center justify-between mb-8">
              <div>
                <h1 className="text-3xl font-bold text-white flex items-center gap-2">
                  <Clapperboard className="w-8 h-8 text-amber-400" /> Auditions Board
                </h1>
                <p className="text-zinc-400 mt-1">Find casting calls and audition opportunities</p>
              </div>
              {(currentUser?.role === 'producer' || currentUser?.role === 'director') && (
                <Button onClick={() => setShowPost(!showPost)} className="bg-amber-500 text-black font-semibold">
                  <Plus className="w-4 h-4 mr-2" /> Post Audition
                </Button>
              )}
            </div>
          </motion.div>

          <AnimatePresence>
            {showPost && (
              <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: 'auto' }} exit={{ opacity: 0, height: 0 }} className="mb-8">
                <Card className="bg-zinc-900/50 border-amber-500/30">
                  <CardHeader><CardTitle className="text-white">Post New Audition</CardTitle></CardHeader>
                  <CardContent className="space-y-4">
                    <div><Label className="text-zinc-300">Audition Title</Label><Input value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} className="bg-zinc-800 border-zinc-700 text-white" /></div>
                    <div><Label className="text-zinc-300">Description</Label><Textarea value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} rows={3} className="bg-zinc-800 border-zinc-700 text-white" /></div>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div><Label className="text-zinc-300">Roles Needed</Label><Input value={form.roles} onChange={(e) => setForm({ ...form, roles: e.target.value })} placeholder="Lead Male, Supporting Female..." className="bg-zinc-800 border-zinc-700 text-white" /></div>
                      <div><Label className="text-zinc-300">Location</Label><Input value={form.location} onChange={(e) => setForm({ ...form, location: e.target.value })} className="bg-zinc-800 border-zinc-700 text-white" /></div>
                      <div><Label className="text-zinc-300">Deadline</Label><Input type="date" value={form.deadline} onChange={(e) => setForm({ ...form, deadline: e.target.value })} className="bg-zinc-800 border-zinc-700 text-white" /></div>
                    </div>
                    <div><Label className="text-zinc-300">Requirements</Label><Textarea value={form.requirements} onChange={(e) => setForm({ ...form, requirements: e.target.value })} rows={2} className="bg-zinc-800 border-zinc-700 text-white" /></div>
                    <div className="flex gap-2">
                      <Button onClick={handlePost} className="bg-amber-500 text-black font-semibold">Post Audition</Button>
                      <Button variant="ghost" className="text-zinc-400" onClick={() => setShowPost(false)}>Cancel</Button>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            )}
          </AnimatePresence>

          {loading ? (
            <div className="space-y-4">{[1, 2, 3].map(i => <Card key={i} className="bg-zinc-900/50 border-zinc-800"><CardContent className="p-6"><Skeleton className="h-6 w-3/4 bg-zinc-800 mb-2" /><Skeleton className="h-4 w-1/2 bg-zinc-800" /></CardContent></Card>)}</div>
          ) : auditions.length === 0 ? (
            <Card className="bg-zinc-900/50 border-zinc-800 p-12 text-center">
              <Clapperboard className="w-16 h-16 text-zinc-700 mx-auto mb-4" />
              <h3 className="text-xl text-zinc-400 mb-2">No auditions posted yet</h3>
              <p className="text-zinc-600">Producers and directors will post casting calls here. Check back soon!</p>
            </Card>
          ) : (
            <div className="space-y-4">
              {auditions.map((audition, i) => (
                <motion.div key={audition.id} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.05 }}>
                  <Card className="bg-zinc-900/50 border-zinc-800 hover:border-amber-500/20 transition-all">
                    <CardContent className="p-6">
                      <div className="flex items-start justify-between gap-4">
                        <div className="flex-1">
                          <h3 className="text-lg font-bold text-white mb-1">{audition.title}</h3>
                          {audition.description && <p className="text-zinc-400 text-sm mb-3 leading-relaxed">{audition.description}</p>}
                          <div className="flex flex-wrap gap-4 text-xs text-zinc-500">
                            {audition.location && <span className="flex items-center gap-1"><MapPin className="w-3.5 h-3.5" /> {audition.location}</span>}
                            {audition.deadline && <span className="flex items-center gap-1"><Calendar className="w-3.5 h-3.5" /> Deadline: {audition.deadline}</span>}
                            {audition.roles && <span className="flex items-center gap-1"><Users className="w-3.5 h-3.5" /> {audition.roles}</span>}
                          </div>
                          {audition.requirements && (
                            <div className="mt-3 p-3 bg-zinc-800/50 rounded-lg">
                              <p className="text-zinc-400 text-xs font-semibold mb-1">Requirements:</p>
                              <p className="text-zinc-500 text-xs">{audition.requirements}</p>
                            </div>
                          )}
                        </div>
                        <Button variant="outline" size="sm" className="border-amber-500/30 text-amber-400 hover:bg-amber-500/10 shrink-0">
                          Apply <ChevronRight className="w-3 h-3 ml-1" />
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          )}
        </div>
      </div>
    );
  };

  // ============================================================
  // SCRIPTS MARKETPLACE
  // ============================================================
  const ScriptsView = () => {
    const [scripts, setScripts] = useState<Script[]>([]);
    const [loading, setLoading] = useState(true);
    const [showPost, setShowPost] = useState(false);
    const [form, setForm] = useState({ title: '', genre: '', synopsis: '', pages: '', contactEmail: '' });

    const fetchScripts = async () => {
      setLoading(true);
      const data = await api('/api/scripts');
      if (data.success) setScripts(data.scripts);
      setLoading(false);
    };

    useEffect(() => { fetchScripts(); }, []);

    const handlePost = async () => {
      if (!currentUser || !form.title) return;
      await api('/api/scripts', { method: 'POST', body: JSON.stringify({ writerId: currentUser.id, ...form, pages: parseInt(form.pages) || 0 }) });
      setForm({ title: '', genre: '', synopsis: '', pages: '', contactEmail: '' });
      setShowPost(false);
      fetchScripts();
    };

    return (
      <div className="min-h-screen bg-black pt-20 pb-12">
        <div className="max-w-4xl mx-auto px-4 sm:px-6">
          <motion.div {...fadeUp}>
            <div className="flex items-center justify-between mb-8">
              <div>
                <h1 className="text-3xl font-bold text-white flex items-center gap-2">
                  <FileText className="w-8 h-8 text-amber-400" /> Scripts Marketplace
                </h1>
                <p className="text-zinc-400 mt-1">Discover original screenplays from talented writers</p>
              </div>
              {currentUser?.role === 'writer' && (
                <Button onClick={() => setShowPost(!showPost)} className="bg-amber-500 text-black font-semibold">
                  <Plus className="w-4 h-4 mr-2" /> Submit Script
                </Button>
              )}
            </div>
          </motion.div>

          <AnimatePresence>
            {showPost && (
              <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: 'auto' }} exit={{ opacity: 0, height: 0 }} className="mb-8">
                <Card className="bg-zinc-900/50 border-amber-500/30">
                  <CardHeader><CardTitle className="text-white">Submit Script</CardTitle></CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div><Label className="text-zinc-300">Title</Label><Input value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} className="bg-zinc-800 border-zinc-700 text-white" /></div>
                      <div><Label className="text-zinc-300">Genre</Label>
                        <Select value={form.genre} onValueChange={(v) => setForm({ ...form, genre: v })}>
                          <SelectTrigger className="bg-zinc-800 border-zinc-700 text-white"><SelectValue /></SelectTrigger>
                          <SelectContent className="bg-zinc-800 border-zinc-700">
                            <SelectItem value="action">Action</SelectItem><SelectItem value="comedy">Comedy</SelectItem><SelectItem value="drama">Drama</SelectItem><SelectItem value="horror">Horror</SelectItem><SelectItem value="romance">Romance</SelectItem><SelectItem value="thriller">Thriller</SelectItem><SelectItem value="sci-fi">Sci-Fi</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div><Label className="text-zinc-300">Pages</Label><Input type="number" value={form.pages} onChange={(e) => setForm({ ...form, pages: e.target.value })} className="bg-zinc-800 border-zinc-700 text-white" /></div>
                      <div><Label className="text-zinc-300">Contact Email</Label><Input type="email" value={form.contactEmail} onChange={(e) => setForm({ ...form, contactEmail: e.target.value })} className="bg-zinc-800 border-zinc-700 text-white" /></div>
                    </div>
                    <div><Label className="text-zinc-300">Synopsis</Label><Textarea value={form.synopsis} onChange={(e) => setForm({ ...form, synopsis: e.target.value })} rows={4} className="bg-zinc-800 border-zinc-700 text-white" /></div>
                    <div className="flex gap-2">
                      <Button onClick={handlePost} className="bg-amber-500 text-black font-semibold">Submit Script</Button>
                      <Button variant="ghost" className="text-zinc-400" onClick={() => setShowPost(false)}>Cancel</Button>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            )}
          </AnimatePresence>

          {loading ? (
            <div className="space-y-4">{[1, 2, 3].map(i => <Card key={i} className="bg-zinc-900/50 border-zinc-800"><CardContent className="p-6"><Skeleton className="h-6 w-3/4 bg-zinc-800 mb-2" /><Skeleton className="h-4 w-full bg-zinc-800" /></CardContent></Card>)}</div>
          ) : scripts.length === 0 ? (
            <Card className="bg-zinc-900/50 border-zinc-800 p-12 text-center">
              <FileText className="w-16 h-16 text-zinc-700 mx-auto mb-4" />
              <h3 className="text-xl text-zinc-400 mb-2">No scripts available yet</h3>
              <p className="text-zinc-600">Writers will submit their screenplays here. Producers can discover new talent!</p>
            </Card>
          ) : (
            <div className="space-y-4">
              {scripts.map((script, i) => (
                <motion.div key={script.id} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.05 }}>
                  <Card className="bg-zinc-900/50 border-zinc-800 hover:border-amber-500/20 transition-all">
                    <CardContent className="p-6">
                      <div className="flex items-start justify-between gap-4">
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-1">
                            <h3 className="text-lg font-bold text-white">{script.title}</h3>
                            {script.genre && <Badge variant="outline" className="text-amber-400 border-amber-500/30 capitalize text-xs">{script.genre}</Badge>}
                            <Badge className="bg-green-500/10 text-green-400 text-xs capitalize">{script.status}</Badge>
                          </div>
                          {script.synopsis && <p className="text-zinc-400 text-sm mb-3 leading-relaxed">{script.synopsis}</p>}
                          <div className="flex flex-wrap gap-4 text-xs text-zinc-500">
                            {script.pages && <span className="flex items-center gap-1"><FileText className="w-3.5 h-3.5" /> {script.pages} pages</span>}
                            {script.contactEmail && <span className="flex items-center gap-1"><Mail className="w-3.5 h-3.5" /> {script.contactEmail}</span>}
                          </div>
                        </div>
                        <Button variant="outline" size="sm" className="border-amber-500/30 text-amber-400 hover:bg-amber-500/10 shrink-0">
                          Contact <ChevronRight className="w-3 h-3 ml-1" />
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          )}
        </div>
      </div>
    );
  };

  // ============================================================
  // MY AUDITIONS MANAGER (Producers/Directors)
  // ============================================================
  const MyAuditionsManager = () => {
    const [auditions, setAuditions] = useState<Audition[]>([]);

    const fetchAuditions = async () => {
      if (!currentUser) return;
      const data = await api(`/api/auditions`);
      if (data.success) setAuditions(data.auditions.filter((a: Audition) => a.postedBy === currentUser.id));
    };

    useEffect(() => { fetchAuditions(); }, []);

    return (
      <div className="space-y-6">
        <h2 className="text-xl font-bold text-white">My Posted Auditions</h2>
        {auditions.length === 0 ? (
          <Card className="bg-zinc-900/50 border-zinc-800 p-8 text-center">
            <Clapperboard className="w-12 h-12 text-zinc-700 mx-auto mb-3" />
            <h3 className="text-zinc-400 mb-1">No auditions posted yet</h3>
            <p className="text-zinc-600 text-sm">Post your first audition to start casting</p>
          </Card>
        ) : (
          <div className="space-y-4">
            {auditions.map((a) => (
              <Card key={a.id} className="bg-zinc-900/50 border-zinc-800">
                <CardContent className="p-4">
                  <h3 className="font-bold text-white">{a.title}</h3>
                  <p className="text-zinc-500 text-sm mt-1">{a.location} {a.deadline && `| Deadline: ${a.deadline}`}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    );
  };

  // ============================================================
  // MY SCRIPTS MANAGER (Writers)
  // ============================================================
  const MyScriptsManager = () => {
    const [scripts, setScripts] = useState<Script[]>([]);

    const fetchScripts = async () => {
      if (!currentUser) return;
      const data = await api('/api/scripts');
      if (data.success) setScripts(data.scripts.filter((s: Script) => s.writerId === currentUser.id));
    };

    useEffect(() => { fetchScripts(); }, []);

    return (
      <div className="space-y-6">
        <h2 className="text-xl font-bold text-white">My Submitted Scripts</h2>
        {scripts.length === 0 ? (
          <Card className="bg-zinc-900/50 border-zinc-800 p-8 text-center">
            <FileText className="w-12 h-12 text-zinc-700 mx-auto mb-3" />
            <h3 className="text-zinc-400 mb-1">No scripts submitted yet</h3>
            <p className="text-zinc-600 text-sm">Submit your first screenplay for producers to discover</p>
          </Card>
        ) : (
          <div className="space-y-4">
            {scripts.map((s) => (
              <Card key={s.id} className="bg-zinc-900/50 border-zinc-800">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="font-bold text-white">{s.title}</h3>
                      <div className="flex gap-3 mt-1 text-xs text-zinc-500">
                        {s.genre && <span className="capitalize">{s.genre}</span>}
                        {s.pages && <span>{s.pages} pages</span>}
                        <span className="capitalize text-green-400">{s.status}</span>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    );
  };

  // ============================================================
  // PREMIUM UPGRADE
  // ============================================================
  const PremiumUpgrade = () => {
    const [upgrading, setUpgrading] = useState(false);
    const [done, setDone] = useState(false);

    const handleUpgrade = async () => {
      if (!currentUser) return;
      setUpgrading(true);
      const data = await api('/api/profile', { method: 'PUT', body: JSON.stringify({ userId: currentUser.id, action: 'upgrade' }) });
      if (data.success) {
        const updated = { ...currentUser, isPremium: true };
        setCurrentUser(updated);
        localStorage.setItem('filmcast_user', JSON.stringify(updated));
        setDone(true);
      }
      setUpgrading(false);
    };

    return (
      <Card className="bg-gradient-to-b from-amber-500/10 to-zinc-900/50 border-amber-500/30">
        <CardHeader className="text-center">
          <div className="w-16 h-16 bg-gradient-to-br from-amber-400 to-amber-600 rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-lg shadow-amber-500/30">
            <Crown className="w-9 h-9 text-black" />
          </div>
          <CardTitle className="text-2xl text-white">Upgrade to Premium</CardTitle>
          <CardDescription className="text-zinc-400">One-time payment of just $1 — unlock everything</CardDescription>
        </CardHeader>
        <CardContent className="text-center space-y-6">
          <div className="text-5xl font-black text-amber-400">$1</div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-left max-w-md mx-auto">
            {[
              'Featured profile badge (PRO)',
              'Unlimited uploads',
              'Priority in search results',
              'Monologue video uploads',
              'Smart recommendation engine',
              'Direct contact access',
              'Early audition access',
            ].map((f, i) => (
              <div key={i} className="flex items-center gap-2 text-sm">
                <CheckCircle2 className="w-4 h-4 text-amber-400 shrink-0" />
                <span className="text-zinc-300">{f}</span>
              </div>
            ))}
          </div>
          {currentUser?.isPremium || done ? (
            <Badge className="bg-green-500 text-white px-4 py-2"><CheckCircle2 className="w-4 h-4 mr-2" />You are already a Premium member!</Badge>
          ) : (
            <Button onClick={handleUpgrade} disabled={upgrading} size="lg" className="bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-black font-bold text-lg px-8 shadow-xl shadow-amber-500/30">
              {upgrading ? 'Processing...' : 'Upgrade Now — $1'}
            </Button>
          )}
          <p className="text-zinc-600 text-xs">In production, this integrates with Stripe/PayPal for real payment processing</p>
        </CardContent>
      </Card>
    );
  };

  // ============================================================
  // RECOMMENDATIONS VIEW
  // ============================================================
  const RecommendationsView = () => {
    if (!currentUser) { setView('login'); return null; }
    return (
      <div className="min-h-screen bg-black pt-20 pb-12">
        <div className="max-w-4xl mx-auto px-4 sm:px-6">
          <motion.div {...fadeUp}>
            <h1 className="text-3xl font-bold text-white flex items-center gap-2 mb-2">
              <Sparkles className="w-8 h-8 text-amber-400" /> Recommended For You
            </h1>
            <p className="text-zinc-400 mb-8">Personalized suggestions based on your role: <Badge className="bg-zinc-800 text-amber-400 capitalize ml-1">{currentUser.role}</Badge></p>
          </motion.div>

          <Tabs defaultValue="main" className="space-y-6">
            <TabsList className="bg-zinc-900 border-zinc-800">
              {currentUser.role === 'actor' && <TabsTrigger value="main" className="data-[state=active]:bg-amber-500 data-[state=active]:text-black">Auditions For You</TabsTrigger>}
              {currentUser.role === 'producer' && <TabsTrigger value="main" className="data-[state=active]:bg-amber-500 data-[state=active]:text-black">Writers For You</TabsTrigger>}
              {currentUser.role === 'director' && <TabsTrigger value="main" className="data-[state=active]:bg-amber-500 data-[state=active]:text-black">Crew For You</TabsTrigger>}
              {(currentUser.role !== 'actor' && currentUser.role !== 'producer' && currentUser.role !== 'director') && <TabsTrigger value="main" className="data-[state=active]:bg-amber-500 data-[state=active]:text-black">Top Opportunities</TabsTrigger>}
              <TabsTrigger value="auditions" className="data-[state=active]:bg-amber-500 data-[state=active]:text-black">Latest Auditions</TabsTrigger>
              <TabsTrigger value="writers" className="data-[state=active]:bg-amber-500 data-[state=active]:text-black">Available Writers</TabsTrigger>
            </TabsList>
            <RecommendationTab type={currentUser.role === 'actor' ? 'auditions-for-actors' : currentUser.role === 'producer' ? 'writers-for-producers' : currentUser.role === 'director' ? 'crew-for-directors' : 'auditions-for-actors'} value="main" />
            <RecommendationTab type="auditions-for-actors" value="auditions" />
            <RecommendationTab type="writers-for-producers" value="writers" />
          </Tabs>
        </div>
      </div>
    );
  };

  const RecommendationTab = ({ type, value }: { type: string; value: string }) => {
    const [items, setItems] = useState<unknown[]>([]);
    const [loading, setLoading] = useState(true);

    const fetchItems = async () => {
      setLoading(true);
      const data = await api(`/api/recommend?type=${type}`);
      if (data.success) setItems(data.items || []);
      setLoading(false);
    };

    useEffect(() => { fetchItems(); }, [type]);

    return (
      <TabsContent value={value}>
        {loading ? (
          <div className="space-y-4">{[1, 2, 3].map(i => <Card key={i} className="bg-zinc-900/50 border-zinc-800"><CardContent className="p-6"><Skeleton className="h-5 w-3/4 bg-zinc-800" /></CardContent></Card>)}</div>
        ) : items.length === 0 ? (
          <Card className="bg-zinc-900/50 border-zinc-800 p-8 text-center">
            <Sparkles className="w-12 h-12 text-zinc-700 mx-auto mb-3" />
            <p className="text-zinc-500">No recommendations yet. Check back soon!</p>
          </Card>
        ) : (
          <div className="space-y-4">
            {items.map((item: unknown, i: number) => {
              const rec = item as Record<string, unknown>;
              return (
                <Card key={i} className="bg-zinc-900/50 border-zinc-800 hover:border-amber-500/20 transition-all">
                  <CardContent className="p-4">
                    <div className="flex items-center gap-4">
                      <div className="w-10 h-10 bg-amber-500/10 rounded-xl flex items-center justify-center shrink-0">
                        {type.includes('audition') ? <Clapperboard className="w-5 h-5 text-amber-400" /> : type.includes('writer') ? <PenTool className="w-5 h-5 text-amber-400" /> : <Wrench className="w-5 h-5 text-amber-400" />}
                      </div>
                      <div className="flex-1 min-w-0">
                        <h3 className="font-bold text-white text-sm truncate">{(rec.title || rec.name) as string}</h3>
                        <p className="text-zinc-500 text-xs truncate">{(rec.description || rec.bio || rec.genre) as string}</p>
                      </div>
                      <ChevronRight className="w-4 h-4 text-zinc-600 shrink-0" />
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        )}
      </TabsContent>
    );
  };

  // ============================================================
  // RENDER CURRENT VIEW
  // ============================================================
  return (
    <div className="min-h-screen bg-black flex flex-col">
      <Navbar />
      <main className="flex-1">
        <AnimatePresence mode="wait">
          {view === 'home' && <motion.div key="home" {...fadeUp}><HomePage /></motion.div>}
          {view === 'browse' && <motion.div key="browse" {...fadeUp}><BrowseView /></motion.div>}
          {view === 'profile' && <motion.div key="profile" {...fadeUp}><ProfileView /></motion.div>}
          {view === 'dashboard' && <motion.div key="dashboard" {...fadeUp}><DashboardView /></motion.div>}
          {view === 'auditions' && <motion.div key="auditions" {...fadeUp}><AuditionsView /></motion.div>}
          {view === 'scripts' && <motion.div key="scripts" {...fadeUp}><ScriptsView /></motion.div>}
          {view === 'recommendations' && <motion.div key="recommendations" {...fadeUp}><RecommendationsView /></motion.div>}
          {view === 'login' && <motion.div key="login" {...fadeUp}><AuthView mode="login" /></motion.div>}
          {view === 'register' && <motion.div key="register" {...fadeUp}><AuthView mode="register" /></motion.div>}
        </AnimatePresence>
      </main>
      {view === 'home' && <Footer />}
    </div>
  );
}
