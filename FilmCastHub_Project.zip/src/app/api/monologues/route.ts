import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

const corsHeaders = { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Methods': 'GET, POST, DELETE, OPTIONS', 'Access-Control-Allow-Headers': 'Content-Type' };

export async function OPTIONS() {
  return NextResponse.json({}, { status: 204, headers: corsHeaders });
}

// GET /api/monologues?userId=xxx
export async function GET(request: NextRequest) {
  try {
    const userId = request.nextUrl.searchParams.get('userId');
    if (!userId) {
      return NextResponse.json({ success: false, error: 'userId is required' }, { status: 400, headers: corsHeaders });
    }

    const monologues = await db.monologue.findMany({
      where: { userId },
      orderBy: { createdAt: 'desc' },
    });

    return NextResponse.json({ success: true, monologues }, { status: 200, headers: corsHeaders });
  } catch (error: unknown) {
    const message = error instanceof Error ? error.message : 'Failed to fetch monologues';
    return NextResponse.json({ success: false, error: message }, { status: 500, headers: corsHeaders });
  }
}

// POST /api/monologues
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { userId, title, genre, description, videoUrl } = body;

    if (!userId || !title) {
      return NextResponse.json({ success: false, error: 'userId and title are required' }, { status: 400, headers: corsHeaders });
    }

    const monologue = await db.monologue.create({
      data: {
        userId,
        title,
        genre: genre || null,
        description: description || null,
        videoUrl: videoUrl || null,
      },
    });

    return NextResponse.json({ success: true, monologue }, { status: 201, headers: corsHeaders });
  } catch (error: unknown) {
    const message = error instanceof Error ? error.message : 'Failed to create monologue';
    return NextResponse.json({ success: false, error: message }, { status: 500, headers: corsHeaders });
  }
}

// DELETE /api/monologues?monologueId=xxx
export async function DELETE(request: NextRequest) {
  try {
    const monologueId = request.nextUrl.searchParams.get('monologueId');
    if (!monologueId) {
      return NextResponse.json({ success: false, error: 'monologueId is required' }, { status: 400, headers: corsHeaders });
    }

    await db.monologue.delete({ where: { id: monologueId } });

    return NextResponse.json({ success: true, message: 'Monologue deleted' }, { status: 200, headers: corsHeaders });
  } catch (error: unknown) {
    const message = error instanceof Error ? error.message : 'Failed to delete monologue';
    return NextResponse.json({ success: false, error: message }, { status: 500, headers: corsHeaders });
  }
}
