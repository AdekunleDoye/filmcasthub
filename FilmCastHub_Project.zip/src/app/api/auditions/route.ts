import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

const corsHeaders = { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Methods': 'GET, POST, OPTIONS', 'Access-Control-Allow-Headers': 'Content-Type' };

export async function OPTIONS() {
  return NextResponse.json({}, { status: 204, headers: corsHeaders });
}

// GET /api/auditions — list all auditions (newest first)
// If ?role=actor, return only open auditions (has deadline in the future or no deadline)
export async function GET(request: NextRequest) {
  try {
    const role = request.nextUrl.searchParams.get('role');

    const whereClause: Record<string, unknown> = {};

    if (role === 'actor') {
      // Return only open auditions: deadline is in the future or not set
      whereClause.OR = [
        { deadline: null },
        { deadline: { gt: new Date().toISOString() } },
      ];
    }

    const auditions = await db.audition.findMany({
      where: whereClause,
      orderBy: { createdAt: 'desc' },
      include: {
        user: {
          select: { id: true, name: true, role: true, avatar: true, location: true },
        },
      },
    });

    return NextResponse.json({ success: true, auditions }, { status: 200, headers: corsHeaders });
  } catch (error: unknown) {
    const message = error instanceof Error ? error.message : 'Failed to fetch auditions';
    return NextResponse.json({ success: false, error: message }, { status: 500, headers: corsHeaders });
  }
}

// POST /api/auditions
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { postedBy, title, description, roles, location, deadline, requirements } = body;

    if (!postedBy || !title) {
      return NextResponse.json({ success: false, error: 'postedBy and title are required' }, { status: 400, headers: corsHeaders });
    }

    const audition = await db.audition.create({
      data: {
        postedBy,
        title,
        description: description || null,
        roles: roles || null,
        location: location || null,
        deadline: deadline || null,
        requirements: requirements || null,
      },
    });

    return NextResponse.json({ success: true, audition }, { status: 201, headers: corsHeaders });
  } catch (error: unknown) {
    const message = error instanceof Error ? error.message : 'Failed to create audition';
    return NextResponse.json({ success: false, error: message }, { status: 500, headers: corsHeaders });
  }
}
