import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

const corsHeaders = { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Methods': 'GET, OPTIONS', 'Access-Control-Allow-Headers': 'Content-Type' };

export async function OPTIONS() {
  return NextResponse.json({}, { status: 204, headers: corsHeaders });
}

// GET /api/members?role=xxx&search=xxx&limit=20&offset=0
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = request.nextUrl;
    const role = searchParams.get('role');
    const search = searchParams.get('search');
    const limit = parseInt(searchParams.get('limit') || '50', 10);
    const offset = parseInt(searchParams.get('offset') || '0', 10);

    const whereClause: Record<string, unknown> = {};

    if (role) {
      whereClause.role = role;
    }

    if (search) {
      whereClause.OR = [
        { name: { contains: search } },
        { bio: { contains: search } },
        { skills: { contains: search } },
      ];
    }

    // Fetch premium users first, then non-premium
    const premiumMembers = await db.user.findMany({
      where: { ...whereClause, isPremium: true },
      orderBy: { createdAt: 'desc' },
      select: {
        id: true,
        email: true,
        name: true,
        role: true,
        phone: true,
        bio: true,
        avatar: true,
        reelUrl: true,
        chargingPrice: true,
        location: true,
        skills: true,
        isPremium: true,
        createdAt: true,
        _count: { select: { works: true, monologues: true } },
      },
    });

    const nonPremiumMembers = await db.user.findMany({
      where: { ...whereClause, isPremium: false },
      orderBy: { createdAt: 'desc' },
      skip: offset,
      take: limit,
      select: {
        id: true,
        email: true,
        name: true,
        role: true,
        phone: true,
        bio: true,
        avatar: true,
        reelUrl: true,
        chargingPrice: true,
        location: true,
        skills: true,
        isPremium: true,
        createdAt: true,
        _count: { select: { works: true, monologues: true } },
      },
    });

    const members = [...premiumMembers, ...nonPremiumMembers];

    return NextResponse.json({ success: true, members }, { status: 200, headers: corsHeaders });
  } catch (error: unknown) {
    const message = error instanceof Error ? error.message : 'Failed to fetch members';
    return NextResponse.json({ success: false, error: message }, { status: 500, headers: corsHeaders });
  }
}
