import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

const corsHeaders = { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Methods': 'GET, OPTIONS', 'Access-Control-Allow-Headers': 'Content-Type' };

export async function OPTIONS() {
  return NextResponse.json({}, { status: 204, headers: corsHeaders });
}

// GET /api/recommend?type=auditions-for-actors
// GET /api/recommend?type=writers-for-producers
// GET /api/recommend?type=crew-for-directors
export async function GET(request: NextRequest) {
  try {
    const type = request.nextUrl.searchParams.get('type');

    switch (type) {
      case 'auditions-for-actors': {
        const auditions = await db.audition.findMany({
          where: {
            OR: [
              { deadline: null },
              { deadline: { gt: new Date().toISOString() } },
            ],
          },
          orderBy: { createdAt: 'desc' },
          take: 10,
          include: {
            user: {
              select: { id: true, name: true, role: true, avatar: true, location: true },
            },
          },
        });
        return NextResponse.json({ success: true, data: auditions }, { status: 200, headers: corsHeaders });
      }

      case 'writers-for-producers': {
        const writers = await db.user.findMany({
          where: { role: 'writer' },
          orderBy: { createdAt: 'desc' },
          take: 10,
          select: {
            id: true,
            email: true,
            name: true,
            role: true,
            bio: true,
            avatar: true,
            location: true,
            skills: true,
            isPremium: true,
            scripts: {
              orderBy: { createdAt: 'desc' },
              take: 5,
            },
          },
        });
        return NextResponse.json({ success: true, data: writers }, { status: 200, headers: corsHeaders });
      }

      case 'crew-for-directors': {
        const crew = await db.user.findMany({
          where: { role: { notIn: ['actor', 'writer'] } },
          orderBy: { createdAt: 'desc' },
          take: 10,
          select: {
            id: true,
            email: true,
            name: true,
            role: true,
            bio: true,
            avatar: true,
            location: true,
            skills: true,
            isPremium: true,
            reelUrl: true,
            _count: { select: { works: true } },
          },
        });
        return NextResponse.json({ success: true, data: crew }, { status: 200, headers: corsHeaders });
      }

      default:
        return NextResponse.json(
          { success: false, error: 'Invalid type. Use: auditions-for-actors, writers-for-producers, or crew-for-directors' },
          { status: 400, headers: corsHeaders }
        );
    }
  } catch (error: unknown) {
    const message = error instanceof Error ? error.message : 'Failed to fetch recommendations';
    return NextResponse.json({ success: false, error: message }, { status: 500, headers: corsHeaders });
  }
}
