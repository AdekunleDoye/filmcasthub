import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

const corsHeaders = { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Methods': 'GET, POST, OPTIONS', 'Access-Control-Allow-Headers': 'Content-Type' };

export async function OPTIONS() {
  return NextResponse.json({}, { status: 204, headers: corsHeaders });
}

// GET /api/scripts — list all scripts with status "available" (newest first)
export async function GET(request: NextRequest) {
  try {
    const scripts = await db.script.findMany({
      where: { status: 'available' },
      orderBy: { createdAt: 'desc' },
      include: {
        writer: {
          select: { id: true, name: true, avatar: true, location: true },
        },
      },
    });

    return NextResponse.json({ success: true, scripts }, { status: 200, headers: corsHeaders });
  } catch (error: unknown) {
    const message = error instanceof Error ? error.message : 'Failed to fetch scripts';
    return NextResponse.json({ success: false, error: message }, { status: 500, headers: corsHeaders });
  }
}

// POST /api/scripts
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { writerId, title, genre, synopsis, pages, contactEmail } = body;

    if (!writerId || !title) {
      return NextResponse.json({ success: false, error: 'writerId and title are required' }, { status: 400, headers: corsHeaders });
    }

    const script = await db.script.create({
      data: {
        writerId,
        title,
        genre: genre || null,
        synopsis: synopsis || null,
        pages: pages || null,
        contactEmail: contactEmail || null,
        status: 'available',
      },
    });

    return NextResponse.json({ success: true, script }, { status: 201, headers: corsHeaders });
  } catch (error: unknown) {
    const message = error instanceof Error ? error.message : 'Failed to create script';
    return NextResponse.json({ success: false, error: message }, { status: 500, headers: corsHeaders });
  }
}
