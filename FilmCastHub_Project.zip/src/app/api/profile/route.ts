import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

const corsHeaders = { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Methods': 'GET, PUT, OPTIONS', 'Access-Control-Allow-Headers': 'Content-Type' };

export async function OPTIONS() {
  return NextResponse.json({}, { status: 204, headers: corsHeaders });
}

// GET /api/profile?userId=xxx
export async function GET(request: NextRequest) {
  try {
    const userId = request.nextUrl.searchParams.get('userId');
    if (!userId) {
      return NextResponse.json({ success: false, error: 'userId is required' }, { status: 400, headers: corsHeaders });
    }

    const user = await db.user.findUnique({
      where: { id: userId },
      include: {
        works: { orderBy: { createdAt: 'desc' } },
        monologues: { orderBy: { createdAt: 'desc' } },
        auditions: { orderBy: { createdAt: 'desc' } },
        scripts: { orderBy: { createdAt: 'desc' } },
      },
    });

    if (!user) {
      return NextResponse.json({ success: false, error: 'User not found' }, { status: 404, headers: corsHeaders });
    }

    const { password: _password, ...safeUser } = user;

    return NextResponse.json({ success: true, user: safeUser }, { status: 200, headers: corsHeaders });
  } catch (error: unknown) {
    const message = error instanceof Error ? error.message : 'Failed to fetch profile';
    return NextResponse.json({ success: false, error: message }, { status: 500, headers: corsHeaders });
  }
}

// PUT /api/profile — update profile fields
// PUT /api/profile?action=upgrade — set isPremium: true
export async function PUT(request: NextRequest) {
  try {
    const url = request.nextUrl.clone();
    const action = url.searchParams.get('action');

    const body = await request.json();
    const { userId } = body;

    if (!userId) {
      return NextResponse.json({ success: false, error: 'userId is required' }, { status: 400, headers: corsHeaders });
    }

    // Upgrade to premium
    if (action === 'upgrade') {
      const user = await db.user.update({
        where: { id: userId },
        data: { isPremium: true },
      });
      return NextResponse.json(
        { success: true, user: { id: user.id, email: user.email, name: user.name, role: user.role, isPremium: user.isPremium } },
        { status: 200, headers: corsHeaders }
      );
    }

    // Update profile fields
    const { name, phone, bio, avatar, reelUrl, chargingPrice, location, skills } = body;
    const updateData: Record<string, string | null | number> = {};
    if (name !== undefined) updateData.name = name;
    if (phone !== undefined) updateData.phone = phone;
    if (bio !== undefined) updateData.bio = bio;
    if (avatar !== undefined) updateData.avatar = avatar;
    if (reelUrl !== undefined) updateData.reelUrl = reelUrl;
    if (chargingPrice !== undefined) updateData.chargingPrice = chargingPrice;
    if (location !== undefined) updateData.location = location;
    if (skills !== undefined) updateData.skills = skills;

    const user = await db.user.update({
      where: { id: userId },
      data: updateData,
    });

    return NextResponse.json(
      { success: true, user: { id: user.id, email: user.email, name: user.name, role: user.role, isPremium: user.isPremium } },
      { status: 200, headers: corsHeaders }
    );
  } catch (error: unknown) {
    const message = error instanceof Error ? error.message : 'Failed to update profile';
    return NextResponse.json({ success: false, error: message }, { status: 500, headers: corsHeaders });
  }
}
