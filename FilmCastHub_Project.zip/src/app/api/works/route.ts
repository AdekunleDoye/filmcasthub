import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

const corsHeaders = { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Methods': 'GET, POST, DELETE, OPTIONS', 'Access-Control-Allow-Headers': 'Content-Type' };

export async function OPTIONS() {
  return NextResponse.json({}, { status: 204, headers: corsHeaders });
}

// GET /api/works?userId=xxx
export async function GET(request: NextRequest) {
  try {
    const userId = request.nextUrl.searchParams.get('userId');
    if (!userId) {
      return NextResponse.json({ success: false, error: 'userId is required' }, { status: 400, headers: corsHeaders });
    }

    const works = await db.work.findMany({
      where: { userId },
      orderBy: { createdAt: 'desc' },
    });

    return NextResponse.json({ success: true, works }, { status: 200, headers: corsHeaders });
  } catch (error: unknown) {
    const message = error instanceof Error ? error.message : 'Failed to fetch works';
    return NextResponse.json({ success: false, error: message }, { status: 500, headers: corsHeaders });
  }
}

// POST /api/works
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { userId, title, type, role, year, description, imageUrl, videoUrl } = body;

    if (!userId || !title || !type) {
      return NextResponse.json({ success: false, error: 'userId, title, and type are required' }, { status: 400, headers: corsHeaders });
    }

    const work = await db.work.create({
      data: {
        userId,
        title,
        type,
        role: role || null,
        year: year || null,
        description: description || null,
        imageUrl: imageUrl || null,
        videoUrl: videoUrl || null,
      },
    });

    return NextResponse.json({ success: true, work }, { status: 201, headers: corsHeaders });
  } catch (error: unknown) {
    const message = error instanceof Error ? error.message : 'Failed to create work';
    return NextResponse.json({ success: false, error: message }, { status: 500, headers: corsHeaders });
  }
}

// DELETE /api/works?workId=xxx
export async function DELETE(request: NextRequest) {
  try {
    const workId = request.nextUrl.searchParams.get('workId');
    if (!workId) {
      return NextResponse.json({ success: false, error: 'workId is required' }, { status: 400, headers: corsHeaders });
    }

    await db.work.delete({ where: { id: workId } });

    return NextResponse.json({ success: true, message: 'Work deleted' }, { status: 200, headers: corsHeaders });
  } catch (error: unknown) {
    const message = error instanceof Error ? error.message : 'Failed to delete work';
    return NextResponse.json({ success: false, error: message }, { status: 500, headers: corsHeaders });
  }
}
